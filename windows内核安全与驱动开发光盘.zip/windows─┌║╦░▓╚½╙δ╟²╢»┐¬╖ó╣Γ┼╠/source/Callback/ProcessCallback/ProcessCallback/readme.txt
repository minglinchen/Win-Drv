========================================================================
    MAKEFILE PROJECT : ProcessCallback Project Overview
========================================================================

AppWizard has created this ProcessCallback project for you.  

This file contains a summary of what you will find in each of the files that
make up your ProcessCallback project.


ProcessCallback.vcproj
    This is the main project file for VC++ projects generated using an Application Wizard. 
    It contains information about the version of Visual C++ that generated the file, and 
    information about the platforms, configurations, and project features selected with the
    Application Wizard.

This project allows you to build/clean/rebuild from within Visual Studio by calling the commands you have input 
in the wizard. The build command can be nmake or any other tool you use.

This project does not contain any files, so there are none displayed in Solution Explorer.

/////////////////////////////////////////////////////////////////////////////
